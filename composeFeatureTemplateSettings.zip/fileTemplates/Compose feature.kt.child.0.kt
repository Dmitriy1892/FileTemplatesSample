#set($PACKAGE_SUFFIX = "")
#parse("CalculatePackage.kt")

class ${NAME}RouterImpl : ${NAME}Router {

    override fun navigateBack() {
        TODO("Not yet implemented")
    }
    
}
